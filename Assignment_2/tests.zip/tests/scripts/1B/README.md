A generator, `gen.py` is provided, refer to the scripts of 1A for testing.
