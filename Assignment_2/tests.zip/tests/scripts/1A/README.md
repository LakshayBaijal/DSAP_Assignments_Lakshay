run `time bash test.sh` (without backticks) to generate input/output pairs in the tests folder.

modify `test.sh` to test *your* solution against the tests generated.
